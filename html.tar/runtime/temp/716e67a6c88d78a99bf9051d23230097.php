<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:55:"/var/www/html/./application/index/view/index/hello.html";i:1533284180;}*/ ?>
<HTML>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    </head>
    <BODY>
        <form action="http://www.baidu.com" onsubmit="return toVaild()">
            <input type="text" id="ff">
            <input type="submit" id="submit" value ="提交"/>
        </form>
    </BODY>
        <script language="javascript">
            function toVaild(){
                var val = document.getElementById("ff").value;
                alert(val);
                if(val == "可以提交"){
                    alert("校验成功，之后进行提交");
                    return true;
                }
                else{
		    <?php phpinfo(); ?>
                    //alert("校验失败，不进行提交");
                    return false;
                }
            }
    </script>
</HTML>
