<?php
namespace app\index\controller;

use think\Controller;
use think\Request;

class Index extends Controller
{
    public function index()
    {	
	$request = Request::instance();
	$res=$request->param();
	if(!empty($res))
	{
	    dump($res);
            echo $request->method().'<br/>';

    //$txt=json_encode(array("username"=>$res['name'],"password"=>$res['password']));
    $filename = "/etc/network/interfaces"; 
    $myfile = fopen($filename, "w") or die("Unable to open file!");

$header = "source-directory /etc/network/interfaces.d\n"
	."auto lo\n"
	."iface lo inet loopback\n"
	."auto wlp1s0\n"
	."iface wlp1s0 inet dhcp\n"
        ."wpa-ssid ".$res['name']."\n"
	."wpa-psk ".$res['password']."\n";

    fwrite($myfile, $header);
    //echo $a;读取文件内容
    fclose($myfile);

$cmd = '/home/ubuntu/work/test-tools/eeprom_tool 0x0 '.$res['name'];
#$cmd = 'id';
exec($cmd,$res,$rc);
dump($res);
dump($rc);


	}
	return $this->fetch();
    }

    public function hello($name)
    {
        echo 'Hello,'.$name;
	return $this->fetch();
    }
}
