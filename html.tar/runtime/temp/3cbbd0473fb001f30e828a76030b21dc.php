<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:55:"/var/www/html/./application/index/view/index/index.html";i:1533288606;}*/ ?>
<HTML>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    </head>
    <BODY>
        <form action="" method="post" onsubmit="return toVaild()">
            <div>Name:<input type="text" id="name" name="name"/></div>
	    <div>Password:<input type="password" id="password" name="password" /></div>
            <div><input type="submit" id="submit" value ="提交"/></div>
        </form>
    </BODY>
        <script language="javascript">
            function toVaild(){
                var val = document.getElementById("ff").value;
                alert(val);
                if(val == "可以提交"){
                    alert("校验成功，之后进行提交");
                    return true;
                }
                else{
		    <?php phpinfo(); ?>
                    //alert("校验失败，不进行提交");
                    return false;
                }
            }
    </script>
</HTML>
